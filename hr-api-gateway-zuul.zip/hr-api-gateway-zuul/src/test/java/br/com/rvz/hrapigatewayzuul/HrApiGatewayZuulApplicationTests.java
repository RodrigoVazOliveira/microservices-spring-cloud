package br.com.rvz.hrapigatewayzuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrApiGatewayZuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
